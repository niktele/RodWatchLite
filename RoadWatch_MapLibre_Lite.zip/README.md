# RoadWatch (MapLibre LITE)

Najlakša verzija bez Firebase-a: dugi pritisak na mapu ➜ Radar/Udes ➜ snima lokalno (SharedPreferences).

## Build (Android Studio)
1) Open projekt (folder sa `settings.gradle`).
2) Sačekaj Gradle Sync.
3) Run ▶ (telefon/emulator) ili Build → Build APK(s).

Nije potreban API ključ niti Firebase.
