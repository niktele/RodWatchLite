package rs.djura.roadwatch.ui

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.location.Location
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.google.android.gms.location.LocationServices
import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView

data class LocalReport(val type: String, val lat: Double, val lng: Double, val ts: Long)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapLibreLiteScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasLocation by remember { mutableStateOf(false) }
    val permLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { res ->
        hasLocation = res[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                      res[Manifest.permission.ACCESS_COARSE_LOCATION] == true
    }
    LaunchedEffect(Unit) {
        permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    val prefs = remember { context.getSharedPreferences("rw_lite", Context.MODE_PRIVATE) }
    var items by remember { mutableStateOf(loadReports(prefs)) }

    var pendingLatLng by remember { mutableStateOf<LatLng?>(null) }
    var selectedType by remember { mutableStateOf("RADAR") }

    if (pendingLatLng != null) {
        AlertDialog(
            onDismissRequest = { pendingLatLng = null },
            confirmButton = {
                TextButton(onClick = {
                    val p = pendingLatLng ?: return@TextButton
                    val new = items.toMutableList()
                    new += LocalReport(selectedType, p.latitude, p.longitude, System.currentTimeMillis())
                    items = new
                    saveReports(prefs, new)
                    pendingLatLng = null
                }) { Text("Sačuvaj") }
            },
            dismissButton = { TextButton(onClick = { pendingLatLng = null }) { Text("Odustani") } },
            title = { Text("Nova prijava") },
            text = {
                Column {
                    Text("Odaberi tip:")
                    FilterChip(selected = selectedType == "RADAR", onClick = { selectedType = "RADAR" }, label = { Text("Radar") })
                    FilterChip(selected = selectedType == "UDES", onClick = { selectedType = "UDES" }, label = { Text("Udes") })
                }
            }
        )
    }

    val mapViewState = remember { mutableStateOf<MapView?>(null) }
    val mapObj = remember { mutableStateOf<MapLibreMap?>(null) }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = { ctx ->
                MapLibre.getInstance(ctx)
                MapView(ctx).also { mv ->
                    mapViewState.value = mv
                    mv.getMapAsync { map ->
                        mapObj.value = map
                        map.setStyle("https://demotiles.maplibre.org/style.json") {
                            val start = LatLng(44.8125, 20.4612) // Beograd
                            map.cameraPosition = CameraPosition.Builder().target(start).zoom(12.0).build()
                            map.addOnMapLongClickListener { p -> pendingLatLng = p; true }

                            if (hasLocation) {
                                val fused = LocationServices.getFusedLocationProviderClient(ctx)
                                fused.lastLocation.addOnSuccessListener { loc: Location? ->
                                    loc?.let {
                                        map.cameraPosition = CameraPosition.Builder()
                                            .target(LatLng(it.latitude, it.longitude))
                                            .zoom(14.0).build()
                                    }
                                }
                            }
                            redrawMarkers(map, items)
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        )
    }

    val mv = mapViewState.value
    val owner = lifecycleOwner
    DisposableEffect(mv, owner) {
        if (mv == null) return@DisposableEffect onDispose {}
        val ob = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_START -> mv.onStart()
                Lifecycle.Event.ON_RESUME -> mv.onResume()
                Lifecycle.Event.ON_PAUSE -> mv.onPause()
                Lifecycle.Event.ON_STOP -> mv.onStop()
                Lifecycle.Event.ON_DESTROY -> mv.onDestroy()
                else -> {}
            }
        }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }

    LaunchedEffect(items, mapObj.value) {
        mapObj.value?.let { map -> redrawMarkers(map, items) }
    }
}

private fun redrawMarkers(map: MapLibreMap, items: List<LocalReport>) {
    map.clear()
    for (r in items) {
        val pos = LatLng(r.lat, r.lng)
        val mo = org.maplibre.android.annotations.MarkerOptions()
            .position(pos)
            .title(if (r.type == "RADAR") "Radar" else "Udes")
            .snippet(java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(java.util.Date(r.ts)))
        map.addMarker(mo)
    }
}

private fun loadReports(prefs: SharedPreferences): List<LocalReport> {
    val raw = prefs.getString("reports", "[]") ?: "[]"
    val arr = JSONArray(raw)
    val out = mutableListOf<LocalReport>()
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        out += LocalReport(
            o.optString("type", "RADAR"),
            o.optDouble("lat", 0.0),
            o.optDouble("lng", 0.0),
            o.optLong("ts", System.currentTimeMillis())
        )
    }
    return out
}

private fun saveReports(prefs: SharedPreferences, items: List<LocalReport>) {
    val arr = JSONArray()
    items.forEach { r ->
        val o = JSONObject()
        o.put("type", r.type); o.put("lat", r.lat); o.put("lng", r.lng); o.put("ts", r.ts)
        arr.put(o)
    }
    prefs.edit().putString("reports", arr.toString()).apply()
}
